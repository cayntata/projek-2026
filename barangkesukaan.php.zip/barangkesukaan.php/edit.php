<?php
require_once 'config/database.php';

$database = new Database();
$conn = $database->getConnection();

// Cek ID
if (!isset($_GET['id'])) {
    setMessage('error', 'ID barang tidak ditemukan');
    redirect('index.php');
}

$id = intval($_GET['id']);

// Ambil data barang
$stmt = $conn->prepare("SELECT * FROM barang WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$barang = $result->fetch_assoc();

if (!$barang) {
    setMessage('error', 'Barang tidak ditemukan');
    redirect('index.php');
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama'] ?? '');
    $jenis = trim($_POST['jenis'] ?? '');
    $merk = trim($_POST['merk'] ?? '');
    $harga = trim($_POST['harga'] ?? '');
    $tanggal_beli = trim($_POST['tanggal_beli'] ?? '');
    $rating = trim($_POST['rating'] ?? '5');
    $deskripsi = trim($_POST['deskripsi'] ?? '');

    // Validasi
    if (empty($nama)) {
        $errors[] = 'Nama barang harus diisi';
    }
    if (empty($jenis)) {
        $errors[] = 'Jenis barang harus dipilih';
    }
    if (!is_numeric($harga) || $harga < 0) {
        $errors[] = 'Harga harus berupa angka positif';
    }
    if ($rating < 1 || $rating > 5) {
        $errors[] = 'Rating harus antara 1-5';
    }

    if (empty($errors)) {
        // Update data
        $stmt = $conn->prepare("UPDATE barang SET 
                                nama = ?, 
                                jenis = ?, 
                                merk = ?, 
                                harga = ?, 
                                tanggal_beli = ?, 
                                rating = ?, 
                                deskripsi = ? 
                                WHERE id = ?");
        $stmt->bind_param("sssdsssi", $nama, $jenis, $merk, $harga, $tanggal_beli, $rating, $deskripsi, $id);
        
        if ($stmt->execute()) {
            setMessage('success', 'Barang berhasil diperbarui!');
            redirect('index.php');
        } else {
            $errors[] = 'Gagal memperbarui barang: ' . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Barang Kesukaan</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-edit"></i> Edit Barang Kesukaan</h1>
            <p>Perbarui informasi barang favorit Anda</p>
        </div>

        <div class="card">
            <a href="index.php" class="btn btn-secondary" style="margin-bottom: 20px;">
                <i class="fas fa-arrow-left"></i> Kembali
            </a>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-error">
                    <div>
                        <strong>Terjadi kesalahan:</strong>
                        <ul style="margin-top: 10px; padding-left: 20px;">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <button onclick="this.parentElement.remove()">&times;</button>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label class="form-label" for="nama">
                        <i class="fas fa-tag"></i> Nama Barang *
                    </label>
                    <input type="text" id="nama" name="nama" class="form-control" required 
                           value="<?php echo htmlspecialchars($barang['nama']); ?>">
                </div>

                <div class="form-group">
                    <label class="form-label" for="jenis">
                        <i class="fas fa-list"></i> Jenis Barang *
                    </label>
                    <select id="jenis" name="jenis" class="form-control" required>
                        <option value="">Pilih Jenis</option>
                        <option value="Elektronik" <?php echo $barang['jenis'] == 'Elektronik' ? 'selected' : ''; ?>>Elektronik</option>
                        <option value="Fashion" <?php echo $barang['jenis'] == 'Fashion' ? 'selected' : ''; ?>>Fashion</option>
                        <option value="Buku" <?php echo $barang['jenis'] == 'Buku' ? 'selected' : ''; ?>>Buku</option>
                        <option value="Hobi" <?php echo $barang['jenis'] == 'Hobi' ? 'selected' : ''; ?>>Hobi</option>
                        <option value="Olahraga" <?php echo $barang['jenis'] == 'Olahraga' ? 'selected' : ''; ?>>Olahraga</option>
                        <option value="Lainnya" <?php echo $barang['jenis'] == 'Lainnya' ? 'selected' : ''; ?>>Lainnya</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label" for="merk">
                        <i class="fas fa-copyright"></i> Merk
                    </label>
                    <input type="text" id="merk" name="merk" class="form-control" 
                           value="<?php echo htmlspecialchars($barang['merk']); ?>">
                </div>

                <div class="form-group">
                    <label class="form-label" for="harga">
                        <i class="fas fa-money-bill-wave"></i> Harga (Rp) *
                    </label>
                    <input type="number" id="harga" name="harga" class="form-control" required 
                           min="0" step="1000" value="<?php echo $barang['harga']; ?>">
                </div>

                <div class="form-group">
                    <label class="form-label" for="tanggal_beli">
                        <i class="fas fa-calendar"></i> Tanggal Beli
                    </label>
                    <input type="date" id="tanggal_beli" name="tanggal_beli" class="form-control" 
                           value="<?php echo $barang['tanggal_beli']; ?>">
                </div>

                <div class="form-group">
                    <label class="form-label" for="rating">
                        <i class="fas fa-star"></i> Rating (1-5)
                    </label>
                    <select id="rating" name="rating" class="form-control">
                        <option value="5" <?php echo $barang['rating'] == 5 ? 'selected' : ''; ?>>5 - Sangat Suka</option>
                        <option value="4" <?php echo $barang['rating'] == 4 ? 'selected' : ''; ?>>4 - Suka</option>
                        <option value="3" <?php echo $barang['rating'] == 3 ? 'selected' : ''; ?>>3 - Cukup</option>
                        <option value="2" <?php echo $barang['rating'] == 2 ? 'selected' : ''; ?>>2 - Kurang Suka</option>
                        <option value="1" <?php echo $barang['rating'] == 1 ? 'selected' : ''; ?>>1 - Tidak Suka</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label" for="deskripsi">
                        <i class="fas fa-align-left"></i> Deskripsi
                    </label>
                    <textarea id="deskripsi" name="deskripsi" class="form-control" 
                              rows="5"><?php echo htmlspecialchars($barang['deskripsi']); ?></textarea>
                </div>

                <div style="display: flex; gap: 10px; margin-top: 30px;">
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save"></i> Update Barang
                    </button>
                    <a href="index.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Batal
                    </a>
                </div>
            </form>
        </div>

        <div class="footer">
            <p>Perbarui informasi barang favorit Anda dengan data yang terbaru</p>
        </div>
    </div>

    <script src="assets/js/script.js"></script>
</body>
</html>