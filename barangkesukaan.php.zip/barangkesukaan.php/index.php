<?php
require_once 'config/database.php';

$database = new Database();
$conn = $database->getConnection();

// Ambil semua data barang
$sql = "SELECT * FROM barang ORDER BY created_at DESC";
$result = $conn->query($sql);

// Hitung statistik
$stats_sql = "SELECT 
    COUNT(*) as total,
    AVG(rating) as avg_rating,
    SUM(harga) as total_harga,
    COUNT(DISTINCT jenis) as jenis_count
    FROM barang";
$stats_result = $conn->query($stats_sql);
$stats = $stats_result->fetch_assoc();

$message = getMessage();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Barang Kesukaan</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1><i class="fas fa-heart"></i> Koleksi Barang Kesukaan</h1>
            <p>Kelola semua barang favorit Anda di satu tempat</p>
        </div>

        <!-- Stats -->
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-value"><?php echo $result->num_rows; ?></div>
                <div class="stat-label">Total Barang</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?php echo number_format($stats['avg_rating'], 1); ?></div>
                <div class="stat-label">Rating Rata-rata</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">Rp <?php echo number_format($stats['total_harga'], 0, ',', '.'); ?></div>
                <div class="stat-label">Total Nilai</div>
            </div>
            <div class="stat-card">
                <div class="stat-value"><?php echo $stats['jenis_count']; ?></div>
                <div class="stat-label">Jenis Barang</div>
            </div>
        </div>

        <!-- Pesan -->
        <?php if ($message): ?>
            <div class="alert alert-<?php echo $message['type'] === 'error' ? 'error' : 'success'; ?>">
                <span><?php echo $message['text']; ?></span>
                <button onclick="this.parentElement.remove()">&times;</button>
            </div>
        <?php endif; ?>

        <!-- Main Content -->
        <div class="card">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <h2><i class="fas fa-box-open"></i> Daftar Barang</h2>
                <a href="tambah.php" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Tambah Barang
                </a>
            </div>

            <?php if ($result->num_rows > 0): ?>
                <div class="table-container">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Barang</th>
                                <th>Jenis</th>
                                <th>Merk</th>
                                <th>Harga</th>
                                <th>Tanggal Beli</th>
                                <th>Rating</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; while($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $no++; ?></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($row['nama']); ?></strong>
                                        <?php if($row['deskripsi']): ?>
                                            <br><small style="color: #666;"><?php echo substr(htmlspecialchars($row['deskripsi']), 0, 50); ?>...</small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?php echo strtolower($row['jenis']); ?>">
                                            <?php echo htmlspecialchars($row['jenis']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo htmlspecialchars($row['merk']); ?></td>
                                    <td class="price">Rp <?php echo number_format($row['harga'], 0, ',', '.'); ?></td>
                                    <td><?php echo date('d-m-Y', strtotime($row['tanggal_beli'])); ?></td>
                                    <td class="rating">
                                        <?php 
                                        for($i = 1; $i <= 5; $i++): 
                                            if($i <= $row['rating']): 
                                                echo '★';
                                            else: 
                                                echo '☆';
                                            endif;
                                        endfor; 
                                        ?>
                                    </td>
                                    <td>
                                        <div style="display: flex; gap: 5px;">
                                            <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <a href="hapus.php?id=<?php echo $row['id']; ?>" 
                                               class="btn btn-danger btn-sm" 
                                               onclick="return confirm('Yakin ingin menghapus barang ini?')">
                                                <i class="fas fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div style="text-align: center; padding: 40px;">
                    <i class="fas fa-box-open" style="font-size: 48px; color: #ccc; margin-bottom: 20px;"></i>
                    <h3 style="color: #666;">Belum ada barang</h3>
                    <p style="color: #888;">Tambahkan barang kesukaan Anda pertama kali</p>
                    <a href="tambah.php" class="btn btn-primary" style="margin-top: 20px;">
                        <i class="fas fa-plus"></i> Tambah Barang Pertama
                    </a>
                </div>
            <?php endif; ?>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>© <?php echo date('Y'); ?> - Koleksi Barang Kesukaan | Dibuat dengan ❤️ menggunakan PHP & MySQL</p>
            <p>Total: <?php echo $result->num_rows; ?> barang | Update terakhir: <?php echo date('d-m-Y H:i:s'); ?></p>
        </div>
    </div>

    <script src="assets/js/script.js"></script>
</body>
</html>