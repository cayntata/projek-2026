<?php
require_once 'config/database.php';

$database = new Database();
$conn = $database->getConnection();

// Cek ID
if (!isset($_GET['id'])) {
    setMessage('error', 'ID barang tidak ditemukan');
    redirect('index.php');
}

$id = intval($_GET['id']);

// Ambil data barang
$stmt = $conn->prepare("SELECT * FROM barang WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$barang = $result->fetch_assoc();

if (!$barang) {
    setMessage('error', 'Barang tidak ditemukan');
    redirect('index.php');
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Barang Kesukaan</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .detail-container {
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 30px;
        }
        
        .detail-sidebar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 15px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .detail-icon {
            font-size: 80px;
            margin-bottom: 20px;
            opacity: 0.8;
        }
        
        .detail-content {
            padding: 20px;
        }
        
        .detail-item {
            margin-bottom: 25px;
            padding-bottom: 25px;
            border-bottom: 1px solid #e5e7eb;
        }
        
        .detail-label {
            font-weight: bold;
            color: #4a5568;
            margin-bottom: 8px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .detail-value {
            font-size: 16px;
            color: #2d3748;
        }
        
        .price-large {
            font-size: 28px;
            font-weight: bold;
            color: #059669;
        }
        
        .rating-large {
            font-size: 24px;
            color: #fbbf24;
        }
        
        @media (max-width: 768px) {
            .detail-container {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1><i class="fas fa-info-circle"></i> Detail Barang Kesukaan</h1>
            <p>Informasi lengkap tentang barang favorit Anda</p>
        </div>

        <!-- Main Content -->
        <div class="card">
            <a href="index.php" class="btn btn-secondary" style="margin-bottom: 20px;">
                <i class="fas fa-arrow-left"></i> Kembali ke Daftar
            </a>

            <div class="detail-container">
                <!-- Sidebar -->
                <div class="detail-sidebar">
                    <div class="detail-icon">
                        <?php 
                        $icon = 'fa-box';
                        switch($barang['jenis']) {
                            case 'Elektronik': $icon = 'fa-laptop'; break;
                            case 'Fashion': $icon = 'fa-tshirt'; break;
                            case 'Buku': $icon = 'fa-book'; break;
                            case 'Hobi': $icon = 'fa-gamepad'; break;
                            case 'Olahraga': $icon = 'fa-running'; break;
                        }
                        ?>
                        <i class="fas <?php echo $icon; ?>"></i>
                    </div>
                    
                    <h2 style="text-align: center; margin-bottom: 10px;"><?php echo htmlspecialchars($barang['nama']); ?></h2>
                    
                    <div style="margin-top: auto; width: 100%;">
                        <div class="badge" style="background: rgba(255,255,255,0.2); color: white; text-align: center; margin-bottom: 10px;">
                            <?php echo htmlspecialchars($barang['jenis']); ?>
                        </div>
                        
                        <div style="display: flex; gap: 15px; justify-content: center; margin-top: 20px;">
                            <a href="edit.php?id=<?php echo $barang['id']; ?>" class="btn btn-warning">
                                <i class="fas fa-edit"></i> Edit
                            </a>
                            <a href="hapus.php?id=<?php echo $barang['id']; ?>" 
                               class="btn btn-danger" 
                               onclick="return confirm('Yakin ingin menghapus barang ini?')">
                                <i class="fas fa-trash"></i> Hapus
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Content -->
                <div class="detail-content">
                    <div class="detail-item">
                        <div class="detail-label">
                            <i class="fas fa-info-circle"></i> Informasi Umum
                        </div>
                        <div class="detail-value">
                            <p><strong>ID Barang:</strong> #<?php echo $barang['id']; ?></p>
                            <p><strong>Merk:</strong> <?php echo $barang['merk'] ? htmlspecialchars($barang['merk']) : '-'; ?></p>
                            <p><strong>Ditambahkan:</strong> <?php echo date('d F Y H:i', strtotime($barang['created_at'])); ?></p>
                        </div>
                    </div>

                    <div class="detail-item">
                        <div class="detail-label">
                            <i class="fas fa-money-bill-wave"></i> Harga
                        </div>
                        <div class="price-large">
                            Rp <?php echo number_format($barang['harga'], 0, ',', '.'); ?>
                        </div>
                    </div>

                    <div class="detail-item">
                        <div class="detail-label">
                            <i class="fas fa-calendar"></i> Tanggal Pembelian
                        </div>
                        <div class="detail-value" style="font-size: 18px;">
                            <?php echo date('d F Y', strtotime($barang['tanggal_beli'])); ?>
                        </div>
                    </div>

                    <div class="detail-item">
                        <div class="detail-label">
                            <i class="fas fa-star"></i> Rating
                        </div>
                        <div class="rating-large">
                            <?php 
                            for($i = 1; $i <= 5; $i++): 
                                if($i <= $barang['rating']): 
                                    echo '★';
                                else: 
                                    echo '☆';
                                endif;
                            endfor; 
                            ?>
                            <span style="font-size: 16px; color: #666; margin-left: 10px;">
                                (<?php echo $barang['rating']; ?>/5)
                            </span>
                        </div>
                    </div>

                    <div class="detail-item">
                        <div class="detail-label">
                            <i class="fas fa-align-left"></i> Deskripsi
                        </div>
                        <div class="detail-value" style="line-height: 1.8; font-size: 16px;">
                            <?php if($barang['deskripsi']): ?>
                                <?php echo nl2br(htmlspecialchars($barang['deskripsi'])); ?>
                            <?php else: ?>
                                <span style="color: #888; font-style: italic;">Tidak ada deskripsi</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p>Detail lengkap barang kesukaan Anda</p>
        </div>
    </div>

    <script src="assets/js/script.js"></script>
</body>
</html>