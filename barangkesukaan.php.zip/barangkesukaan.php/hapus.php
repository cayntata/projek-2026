<?php
require_once 'config/database.php';

$database = new Database();
$conn = $database->getConnection();

// Cek ID
if (!isset($_GET['id'])) {
    setMessage('error', 'ID barang tidak ditemukan');
    redirect('index.php');
}

$id = intval($_GET['id']);

// Ambil nama barang sebelum dihapus (untuk pesan)
$stmt = $conn->prepare("SELECT nama FROM barang WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$barang = $result->fetch_assoc();

if (!$barang) {
    setMessage('error', 'Barang tidak ditemukan');
    redirect('index.php');
}

// Hapus data dari database
$stmt = $conn->prepare("DELETE FROM barang WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    setMessage('success', 'Barang "' . $barang['nama'] . '" berhasil dihapus!');
} else {
    setMessage('error', 'Gagal menghapus barang: ' . $conn->error);
}

redirect('index.php');
?>