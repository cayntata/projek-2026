<?php
require_once 'config/database.php';

$database = new Database();
$conn = $database->getConnection();

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama'] ?? '');
    $jenis = trim($_POST['jenis'] ?? '');
    $merk = trim($_POST['merk'] ?? '');
    $harga = trim($_POST['harga'] ?? '');
    $tanggal_beli = trim($_POST['tanggal_beli'] ?? '');
    $rating = trim($_POST['rating'] ?? '5');
    $deskripsi = trim($_POST['deskripsi'] ?? '');

    // Validasi
    if (empty($nama)) {
        $errors[] = 'Nama barang harus diisi';
    }
    if (empty($jenis)) {
        $errors[] = 'Jenis barang harus dipilih';
    }
    if (!is_numeric($harga) || $harga < 0) {
        $errors[] = 'Harga harus berupa angka positif';
    }
    if ($rating < 1 || $rating > 5) {
        $errors[] = 'Rating harus antara 1-5';
    }

    if (empty($errors)) {
        // Insert ke database
        $stmt = $conn->prepare("INSERT INTO barang (nama, jenis, merk, harga, tanggal_beli, rating, deskripsi) 
                                VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssdsss", $nama, $jenis, $merk, $harga, $tanggal_beli, $rating, $deskripsi);
        
        if ($stmt->execute()) {
            setMessage('success', 'Barang berhasil ditambahkan!');
            redirect('index.php');
        } else {
            $errors[] = 'Gagal menambahkan barang: ' . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Barang Kesukaan</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><i class="fas fa-plus-circle"></i> Tambah Barang Kesukaan</h1>
            <p>Tambahkan barang favorit baru ke koleksi Anda</p>
        </div>

        <div class="card">
            <a href="index.php" class="btn btn-secondary" style="margin-bottom: 20px;">
                <i class="fas fa-arrow-left"></i> Kembali
            </a>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-error">
                    <div>
                        <strong>Terjadi kesalahan:</strong>
                        <ul style="margin-top: 10px; padding-left: 20px;">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <button onclick="this.parentElement.remove()">&times;</button>
                </div>
            <?php endif; ?>

            <form method="POST" action="">
                <div class="form-group">
                    <label class="form-label" for="nama">
                        <i class="fas fa-tag"></i> Nama Barang *
                    </label>
                    <input type="text" id="nama" name="nama" class="form-control" required 
                           placeholder="Contoh: Laptop Gaming, Sepatu Lari, dll.">
                </div>

                <div class="form-group">
                    <label class="form-label" for="jenis">
                        <i class="fas fa-list"></i> Jenis Barang *
                    </label>
                    <select id="jenis" name="jenis" class="form-control" required>
                        <option value="">Pilih Jenis</option>
                        <option value="Elektronik">Elektronik</option>
                        <option value="Fashion">Fashion</option>
                        <option value="Buku">Buku</option>
                        <option value="Hobi">Hobi</option>
                        <option value="Olahraga">Olahraga</option>
                        <option value="Lainnya">Lainnya</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label" for="merk">
                        <i class="fas fa-copyright"></i> Merk
                    </label>
                    <input type="text" id="merk" name="merk" class="form-control" 
                           placeholder="Contoh: Nike, Samsung, dll.">
                </div>

                <div class="form-group">
                    <label class="form-label" for="harga">
                        <i class="fas fa-money-bill-wave"></i> Harga (Rp) *
                    </label>
                    <input type="number" id="harga" name="harga" class="form-control" required 
                           min="0" step="1000" placeholder="Contoh: 1500000">
                </div>

                <div class="form-group">
                    <label class="form-label" for="tanggal_beli">
                        <i class="fas fa-calendar"></i> Tanggal Beli
                    </label>
                    <input type="date" id="tanggal_beli" name="tanggal_beli" class="form-control">
                </div>

                <div class="form-group">
                    <label class="form-label" for="rating">
                        <i class="fas fa-star"></i> Rating (1-5)
                    </label>
                    <select id="rating" name="rating" class="form-control">
                        <option value="5">5 - Sangat Suka</option>
                        <option value="4">4 - Suka</option>
                        <option value="3">3 - Cukup</option>
                        <option value="2">2 - Kurang Suka</option>
                        <option value="1">1 - Tidak Suka</option>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label" for="deskripsi">
                        <i class="fas fa-align-left"></i> Deskripsi
                    </label>
                    <textarea id="deskripsi" name="deskripsi" class="form-control" 
                              placeholder="Ceritakan mengapa barang ini menjadi favorit Anda..."></textarea>
                </div>

                <div style="display: flex; gap: 10px; margin-top: 30px;">
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-save"></i> Simpan Barang
                    </button>
                    <a href="index.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Batal
                    </a>
                </div>
            </form>
        </div>

        <div class="footer">
            <p>Tambah barang kesukaan Anda dengan detail yang lengkap</p>
        </div>
    </div>

    <script src="assets/js/script.js"></script>
</body>
</html>